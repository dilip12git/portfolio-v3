import LargeImg from "../assets/dilip-large-img.jpeg";
import { Globe, Cpu, Layers, Sparkles, MapPin, Award } from "lucide-react";

const focusAreas = [
  {
    icon: Globe,
    title: "Web & Mobile Platforms",
    desc: "React, React Native, Node.js, and modern cross-platform architectures.",
  },
  {
    icon: Cpu,
    title: "Agentic AI & LangChain",
    desc: "Intelligent systems with RAG, FastAPI, and autonomous workflows.",
  },
  {
    icon: Layers,
    title: "Architecture & UX",
    desc: "High-performance, accessible, and maintainable user experiences.",
  },
];

export default function About() {
  return (
    <div className="min-h-screen flex flex-col justify-center bg-[var(--bg-card)] py-20 lg:py-28 relative">
      {/* Background soft accent */}
      <div
        className="absolute top-1/3 left-0 w-80 h-80 rounded-full pointer-events-none opacity-20 dark:opacity-10 blur-3xl"
        style={{
          background: "radial-gradient(circle, rgba(99, 102, 241, 0.2) 0%, transparent 70%)",
        }}
      />

      <div className="max-w-6xl mx-auto w-full px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="mb-12">
          <p className="text-xs text-[var(--text-muted)] uppercase tracking-widest mb-2 font-medium flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-[var(--text)]" />
            Introduction
          </p>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-Ovo tracking-tight text-[var(--text)]">
            About me
          </h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* LEFT: Editorial Narrative (7 cols) */}
          <div className="lg:col-span-7 flex flex-col gap-5">
            <p className="text-sm sm:text-base text-[var(--text-muted)] leading-relaxed">
              I'm <strong className="text-[var(--text)] font-semibold">Dilip Kumar Teli</strong>, a Full Stack Developer passionate about building intelligent, scalable and user-centric digital products. With experience spanning web development, mobile applications and AI-powered solutions, I enjoy transforming complex ideas into seamless, impactful experiences.
            </p>

            <p className="text-sm sm:text-base text-[var(--text-muted)] leading-relaxed">
              My expertise includes developing responsive web applications, cross-platform mobile apps and AI-driven systems using modern technologies such as React, React Native, Node.js, Express.js, MongoDB, FastAPI, LangChain and Agentic AI frameworks. I focus on creating high-performance, maintainable and accessible solutions that balance technical excellence with exceptional user experience.
            </p>

            <p className="text-sm sm:text-base text-[var(--text-muted)] leading-relaxed">
              Whether I'm architecting full-stack platforms, designing intuitive user interfaces or integrating AI capabilities into real-world applications, my goal is to build innovative products that solve meaningful problems and deliver measurable value.
            </p>

            {/* 3 Value Pillars */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3">
              {focusAreas.map((area) => {
                const Icon = area.icon;
                return (
                  <div
                    key={area.title}
                    className="p-3.5 rounded-xl border border-[var(--border)] bg-[var(--bg)] hover:border-[var(--border-hover)] transition-colors shadow-xs"
                  >
                    <div className="w-8 h-8 rounded-lg bg-[var(--bg-card)] border border-[var(--border)] flex items-center justify-center text-[var(--text)] mb-2.5">
                      <Icon size={15} />
                    </div>
                    <p className="text-xs font-semibold text-[var(--text)] leading-snug">{area.title}</p>
                    <p className="text-[11px] text-[var(--text-muted)] mt-1 leading-normal">{area.desc}</p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* RIGHT: Photo with Floating Glass Accents (5 cols) */}
          <div className="lg:col-span-5 flex justify-center">
            <div className="relative group max-w-sm w-full">
              {/* Outer Decorative frame glow */}
              <div className="absolute -inset-1.5 rounded-3xl bg-gradient-to-tr from-[var(--border)] via-[var(--border-hover)] to-transparent opacity-70 group-hover:opacity-100 transition-opacity blur-xs" />

              {/* Image Container */}
              <div className="relative rounded-2xl overflow-hidden border border-[var(--border)] bg-[var(--bg)] shadow-lg aspect-square">
                <img
                  src={LargeImg}
                  alt="Dilip Kumar Teli"
                  className="w-full h-full object-cover object-center grayscale hover:grayscale-0 transition-all duration-700 ease-out transform group-hover:scale-105"
                />

                {/* Bottom Glass Badge */}
                <div className="absolute bottom-3 left-3 right-3 p-3.5 rounded-xl glass-pill bg-[var(--bg-card)]/85 dark:bg-[var(--bg-card)]/80 backdrop-blur-md border border-[var(--border)] flex items-center justify-between shadow-md">
                  <div>
                    <p className="text-xs font-semibold text-[var(--text)] leading-tight">Dilip Kumar Teli</p>
                    <p className="text-[10px] text-[var(--text-muted)] flex items-center gap-1 mt-0.5">
                      <MapPin size={10} /> Chennai, India
                    </p>
                  </div>
                  <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-[var(--text)] text-[var(--bg)]">
                    Full Stack &amp; AI
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
