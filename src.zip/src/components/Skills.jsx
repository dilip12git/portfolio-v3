import { useState } from "react";
import { Sparkles, Brain, Cpu, Code2, Database, Wrench } from "lucide-react";

const skillCategories = [
  {
    id: "all",
    label: "All Skills",
  },
  {
    id: "frontend",
    label: "Frontend",
    icon: Code2,
  },
  {
    id: "backend",
    label: "Backend",
    icon: Cpu,
  },
  {
    id: "ai",
    label: "Agentic AI",
    icon: Brain,
  },
  {
    id: "database",
    label: "Database",
    icon: Database,
  },
  {
    id: "tools",
    label: "Tools & Others",
    icon: Wrench,
  },
];

const allSkills = [
  // Frontend
  { name: "HTML5", category: "frontend", icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg" },
  { name: "CSS3", category: "frontend", icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-original.svg" },
  { name: "JavaScript", category: "frontend", icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg" },
  { name: "React JS", category: "frontend", icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/react/react-original.svg" },
  { name: "React Native", category: "frontend", icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/react/react-original.svg" },
  { name: "Angular JS", category: "frontend", icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/angularjs/angularjs-original.svg" },
  { name: "Tailwind CSS", category: "frontend", icon: "https://www.vectorlogo.zone/logos/tailwindcss/tailwindcss-icon.svg" },
  { name: "Redux", category: "frontend", icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/redux/redux-original.svg" },

  // Backend
  { name: "Node.js", category: "backend", icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/nodejs/nodejs-original.svg" },
  { name: "Express.js", category: "backend", icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/express/express-original.svg", invertDark: true },
  { name: "FastAPI", category: "backend", icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/fastapi/fastapi-original.svg" },
  { name: "Python", category: "backend", icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg" },

  // Agentic AI
  { name: "LangChain", category: "ai", icon: "https://cdn.simpleicons.org/langchain", isAi: true },
  { name: "LangGraph", category: "ai", fallback: "🕸", isAi: true },
  { name: "RAG Systems", category: "ai", fallback: "⚡", isAi: true },

  // Database
  { name: "MySQL", category: "database", icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mysql/mysql-original.svg" },
  { name: "MongoDB", category: "database", icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mongodb/mongodb-original.svg" },
  { name: "Firebase", category: "database", icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/firebase/firebase-plain.svg" },

  // Other Languages
  { name: "C++", category: "tools", icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/cplusplus/cplusplus-original.svg" },
  { name: "Java", category: "tools", icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg" },

  // Tools
  { name: "GitHub", category: "tools", icon: "https://www.vectorlogo.zone/logos/github/github-icon.svg", invertDark: true },
  { name: "Git", category: "tools", icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/git/git-original.svg" },
  { name: "Android Studio", category: "tools", icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/androidstudio/androidstudio-original.svg" },
  { name: "Postman", category: "tools", icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/postman/postman-original.svg" },
  { name: "VS Code", category: "tools", icon: "https://cdn.jsdelivr.net/gh/devicons/devicon/icons/vscode/vscode-original.svg" },
  { name: "Cloudinary", category: "tools", icon: "https://cdn.simpleicons.org/cloudinary/3448C5" },
];

export default function Skills() {
  const [selectedCategory, setSelectedCategory] = useState("all");

  const filteredSkills =
    selectedCategory === "all"
      ? allSkills
      : allSkills.filter((s) => s.category === selectedCategory);

  return (
    <div className="min-h-screen flex flex-col justify-center bg-theme py-20 lg:py-28 relative">
      <div className="max-w-6xl mx-auto w-full px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div>
            <p className="text-xs text-[var(--text-muted)] uppercase tracking-widest mb-2 font-medium flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-[var(--text)]" />
              What I know
            </p>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-Ovo tracking-tight text-[var(--text)]">
              Skills &amp; Technologies
            </h2>
          </div>

          {/* Quick AI Callout Badge */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-purple-500/30 bg-purple-500/5 text-purple-600 dark:text-purple-400 text-xs font-medium self-start md:self-auto shadow-xs">
            <Sparkles size={13} className="text-purple-500 animate-spin-slow" />
            <span>Specializing in AI-Driven Workflows</span>
          </div>
        </div>

        {/* Category Pills Filter */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 no-scrollbar">
          {skillCategories.map((cat) => {
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-4 py-2 rounded-full text-xs font-medium transition-all duration-200 whitespace-nowrap flex items-center gap-1.5 ${
                  isSelected
                    ? "bg-[var(--text)] text-[var(--bg)] shadow-sm font-semibold scale-102"
                    : "bg-[var(--bg-card)] border border-[var(--border)] text-[var(--text-muted)] hover:text-[var(--text)] hover:border-[var(--border-hover)]"
                }`}
              >
                {cat.icon && <cat.icon size={13} />}
                <span>{cat.label}</span>
                {isSelected && (
                  <span className="ml-1 px-1.5 py-0.2 rounded-full bg-[var(--bg)] text-[var(--text)] text-[10px]">
                    {filteredSkills.length}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Skills Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3.5">
          {filteredSkills.map((skill) => (
            <div
              key={skill.name}
              className={`group glass-card rounded-2xl p-4 flex flex-col items-center justify-center gap-3 relative transition-all duration-300 hover:-translate-y-1.5 ${
                skill.isAi
                  ? "border-purple-500/30 hover:border-purple-500/60 dark:hover:border-purple-400/60"
                  : ""
              }`}
            >
              {skill.isAi && (
                <span className="absolute top-2 right-2 px-1.5 py-0.5 rounded-full text-[9px] font-semibold bg-purple-500/10 text-purple-600 dark:text-purple-400 border border-purple-500/20">
                  AI
                </span>
              )}

              {/* Icon Container */}
              <div className="w-11 h-11 rounded-xl bg-[var(--bg)] border border-[var(--border)] flex items-center justify-center p-2 group-hover:scale-110 transition-transform duration-300 shadow-xs">
                {skill.icon ? (
                  <img
                    src={skill.icon}
                    alt={skill.name}
                    className={`w-7 h-7 object-contain ${
                      skill.invertDark ? "dark:invert" : ""
                    }`}
                    loading="lazy"
                  />
                ) : (
                  <span className="text-xl">{skill.fallback}</span>
                )}
              </div>

              {/* Name */}
              <span className="text-xs font-semibold text-[var(--text)] text-center leading-tight">
                {skill.name}
              </span>
            </div>
          ))}
        </div>

        {/* Category Breakdown Footer */}
        {selectedCategory === "all" && (
          <div className="mt-12 pt-8 border-t border-[var(--border)] flex flex-wrap items-center justify-between gap-4 text-xs text-[var(--text-muted)]">
            <span className="font-medium">
              Over {allSkills.length} technologies across Frontend, Backend, AI &amp; Cloud.
            </span>
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500" /> Web &amp; Mobile
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-purple-500" /> AI &amp; LangChain
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-blue-500" /> APIs &amp; Databases
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}