import { useEffect, useState } from "react";
import { Moon, Sun, Menu, X, ArrowUpRight, Sparkles } from "lucide-react";

const navItems = [
  { label: "About", id: "about" },
  { label: "Skills", id: "skills" },
  { label: "Experience", id: "experience" },
  { label: "Work", id: "work" },
  { label: "Education", id: "education" },
  { label: "Certifications", id: "certifications" },
  { label: "Services", id: "services" },
];

export default function Navbar() {
  const [dark, setDark] = useState(false);
  const [active, setActive] = useState("hero");
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const isDark =
      localStorage.theme === "dark" ||
      (!("theme" in localStorage) &&
        window.matchMedia("(prefers-color-scheme: dark)").matches);
    setDark(isDark);
    document.documentElement.classList.toggle("dark", isDark);
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      // Calculate scroll progress percentage
      const winScroll = document.documentElement.scrollTop || document.body.scrollTop;
      const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
      const scrolledPct = height > 0 ? (winScroll / height) * 100 : 0;
      setScrollProgress(scrolledPct);
      setScrolled(winScroll > 30);

      // Determine active section based on scroll position
      const sections = [{ id: "hero" }, ...navItems].map((n) =>
        document.getElementById(n.id)
      );
      let current = "hero";
      const scrollPosition = winScroll + 200;

      sections.forEach((sec) => {
        if (!sec) return;
        const top = sec.offsetTop;
        const height = sec.offsetHeight;
        if (scrollPosition >= top && scrollPosition < top + height) {
          current = sec.id;
        }
      });
      setActive(current);
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const toggleTheme = () => {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle("dark", next);
    localStorage.theme = next ? "dark" : "light";
  };

  const scrollTo = (id) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
    setMenuOpen(false);
  };

  return (
    <>
      {/* Scroll Progress Bar */}
      <div
        className="fixed top-0 left-0 h-[2.5px] bg-gradient-to-r from-[var(--text)] via-[var(--text-muted)] to-[var(--text)] z-[60] transition-all duration-100 ease-out"
        style={{ width: `${scrollProgress}%` }}
      />

      {/* Main Navbar */}
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? "glass-nav py-3 shadow-sm shadow-black/5"
            : "bg-transparent py-4 sm:py-5"
        }`}
      >
        <div className="max-w-6xl mx-auto px-6 lg:px-8 flex items-center justify-between">
          <div className="flex items-center gap-7">
            {/* Logo Monogram */}
            <button
              onClick={() => scrollTo("hero")}
              className="group flex items-center gap-3 text-left focus:outline-none"
              aria-label="Dilip Kumar - Home"
            >
              <div className="w-9 h-9 rounded-xl flex items-center justify-center transition-transform duration-300 group-hover:scale-105 shadow-sm">
                <svg viewBox="0 0 120 120" className="w-full h-full">
                  <path
                    d="M60 12 Q68 12 74 18 L100 38 Q108 44 105 54 L92 94 Q89 106 76 106 L44 106 Q31 106 28 94 L15 54 Q12 44 20 38 L46 18 Q52 12 60 12 Z"
                    fill="var(--logo-bg)"
                  />
                  <text
                    x="60"
                    y="72"
                    textAnchor="middle"
                    fill="var(--logo-text)"
                    fontSize="34"
                    fontWeight="900"
                    fontFamily="sans-serif"
                  >
                    DK
                  </text>
                </svg>
              </div>
              <div className="hidden sm:flex flex-col">
                <span className="text-sm font-semibold tracking-tight text-[var(--text)] leading-tight">
                  Dilip Kumar
                </span>
                <span className="text-[10px] text-[var(--text-muted)] tracking-wider uppercase font-medium flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  Full Stack & AI
                </span>
              </div>
            </button>

            {/* Desktop Nav Links */}
            <nav className="hidden lg:flex items-center gap-1 bg-[var(--bg-card)]/60 dark:bg-[var(--bg-card)]/40 backdrop-blur-md px-3 py-1.5 rounded-full border border-[var(--border)]">
              {navItems.map((item) => {
                const isActive = active === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => scrollTo(item.id)}
                    className={`relative px-3.5 py-1 text-xs font-medium rounded-full transition-all duration-200 ${
                      isActive
                        ? "text-[var(--accent-fg)] bg-[var(--accent)] shadow-sm"
                        : "text-[var(--text-muted)] hover:text-[var(--text)] hover:bg-[var(--bg)]/50"
                    }`}
                  >
                    {item.label}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Right Action Controls */}
          <div className="flex items-center gap-2.5">
            {/* Dark / Light Toggle */}
            <button
              onClick={toggleTheme}
              className="w-9 h-9 flex items-center justify-center rounded-full border border-[var(--border)] bg-[var(--bg-card)] text-[var(--text)] hover:border-[var(--text-muted)] hover:scale-105 active:scale-95 transition shadow-sm"
              aria-label="Toggle dark mode"
            >
              {dark ? (
                <Sun size={15} className="rotate-0 hover:rotate-90 transition-transform duration-300" />
              ) : (
                <Moon size={15} className="rotate-0 hover:-rotate-12 transition-transform duration-300" />
              )}
            </button>

            {/* Get in touch CTA button */}
            <button
              onClick={() => scrollTo("contact")}
              className="hidden sm:inline-flex items-center gap-1.5 px-4.5 py-2 rounded-full bg-[var(--text)] text-[var(--bg)] text-xs font-semibold hover:opacity-90 active:scale-95 transition-all shadow-sm group"
            >
              <span>Get in touch</span>
              <ArrowUpRight size={13} className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </button>

            {/* Mobile Menu Button */}
            <button
              className="lg:hidden w-9 h-9 rounded-full border border-[var(--border)] bg-[var(--bg-card)] flex items-center justify-center text-[var(--text)] hover:border-[var(--text-muted)] transition"
              onClick={() => setMenuOpen(true)}
              aria-label="Open menu"
            >
              <Menu size={18} />
            </button>
          </div>
        </div>
      </header>

      {/* Floating Section Navigator (Desktop Left) */}
      <div className="hidden xl:flex fixed left-6 top-1/2 -translate-y-1/2 flex-col gap-3 z-40 bg-[var(--bg-card)]/70 dark:bg-[var(--bg-card)]/50 backdrop-blur-md p-2 rounded-full border border-[var(--border)] shadow-sm">
        {[{ id: "hero", label: "Home" }, ...navItems].map((item) => (
          <button
            key={item.id}
            onClick={() => scrollTo(item.id)}
            title={item.label}
            className="group relative flex items-center justify-center p-1"
          >
            <span
              className={`block rounded-full transition-all duration-300 ${
                active === item.id
                  ? "w-2.5 h-6 bg-[var(--text)] rounded-full"
                  : "w-2 h-2 bg-[var(--border-hover)] group-hover:bg-[var(--text-muted)] group-hover:scale-125"
              }`}
            />
            <span className="absolute left-7 px-2 py-1 bg-[var(--text)] text-[var(--bg)] text-[10px] font-medium rounded-md opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity duration-200 whitespace-nowrap shadow-md">
              {item.label}
            </span>
          </button>
        ))}
      </div>

      {/* Mobile Drawer */}
      {menuOpen && (
        <div className="fixed inset-0 z-50 flex lg:hidden">
          <div
            className="flex-1 bg-black/40 backdrop-blur-sm transition-opacity"
            onClick={() => setMenuOpen(false)}
          />
          <div className="w-72 bg-[var(--bg-card)] border-l border-[var(--border)] flex flex-col p-6 shadow-2xl animate-slideLeft">
            <div className="flex items-center justify-between pb-6 border-b border-[var(--border)]">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center">
                  <svg viewBox="0 0 120 120" className="w-full h-full">
                    <path
                      d="M60 12 Q68 12 74 18 L100 38 Q108 44 105 54 L92 94 Q89 106 76 106 L44 106 Q31 106 28 94 L15 54 Q12 44 20 38 L46 18 Q52 12 60 12 Z"
                      fill="var(--logo-bg)"
                    />
                    <text
                      x="60"
                      y="72"
                      textAnchor="middle"
                      fill="var(--logo-text)"
                      fontSize="34"
                      fontWeight="900"
                    >
                      DK
                    </text>
                  </svg>
                </div>
                <span className="font-semibold text-sm">Dilip Kumar</span>
              </div>
              <button
                onClick={() => setMenuOpen(false)}
                className="w-8 h-8 rounded-full border border-[var(--border)] flex items-center justify-center text-[var(--text)]"
                aria-label="Close menu"
              >
                <X size={16} />
              </button>
            </div>

            <ul className="flex flex-col gap-2 mt-6">
              {[{ id: "hero", label: "Home" }, ...navItems].map((item) => {
                const isActive = active === item.id;
                return (
                  <li key={item.id}>
                    <button
                      onClick={() => scrollTo(item.id)}
                      className={`w-full text-left px-4 py-2.5 rounded-xl text-sm font-medium transition ${
                        isActive
                          ? "bg-[var(--text)] text-[var(--bg)] font-semibold"
                          : "text-[var(--text-muted)] hover:bg-[var(--bg)] hover:text-[var(--text)]"
                      }`}
                    >
                      {item.label}
                    </button>
                  </li>
                );
              })}
            </ul>

            <div className="mt-auto pt-6 border-t border-[var(--border)] flex flex-col gap-3">
              <button
                onClick={() => scrollTo("contact")}
                className="w-full flex items-center justify-center gap-2 py-3 rounded-full bg-[var(--text)] text-[var(--bg)] text-xs font-semibold hover:opacity-90 transition"
              >
                <span>Get in touch</span>
                <ArrowUpRight size={13} />
              </button>
              <div className="flex items-center justify-between text-[11px] text-[var(--text-muted)] px-2">
                <span>© {new Date().getFullYear()} Dilip Kumar</span>
                <span className="flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  Available for hire
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
