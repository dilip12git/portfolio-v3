import Navbar from "./components/NavBar";
import Hero from "./components/Hero";
import Experience from "./components/Experience";
import About from "./components/About";
import Work from "./components/Work";
import Services from "./components/Services";
import Contact from "./components/Contact";
import Education from "./components/Education";
import Skills from "./components/Skills";
import Certifications from "./components/Certificate";

function App() {
  return (
    <div className="font-Outfit bg-theme text-theme selection:bg-[var(--text)] selection:text-[var(--bg)] min-h-screen">
      <Navbar />
      <main className="w-full relative">
        <section id="hero" className="scroll-mt-16">
          <Hero />
        </section>
        <section id="about" className="scroll-mt-16">
          <About />
        </section>
        <section id="skills" className="scroll-mt-16">
          <Skills />
        </section>
        <section id="experience" className="scroll-mt-16">
          <Experience />
        </section>
        <section id="work" className="scroll-mt-16">
          <Work />
        </section>
        <section id="education" className="scroll-mt-16">
          <Education />
        </section>
        <section id="certifications" className="scroll-mt-16">
          <Certifications />
        </section>
        <section id="services" className="scroll-mt-16">
          <Services />
        </section>
        <section id="contact" className="scroll-mt-16">
          <Contact />
        </section>
      </main>
    </div>
  );
}

export default App;
